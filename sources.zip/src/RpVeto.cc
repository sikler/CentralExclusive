#include "../interface/RpVeto.h"

#include "../interface/Structures.h"
#include "../interface/Helper.h"
#include "../interface/Random.h"

#include <iostream>
#include <cmath>
#include <map>

using namespace std;

const int nEvents_rp_eff = 4e+8; // PARAMETER
const double minRpEff = 1e-2;    // PARAMETER

/*****************************************************************************/
// flag =-1 : do nothing
// flag = 1 : collect for veto
// flag = 0 : calculate angular efficiency
// flag = 2 : read and use roman pot efficiency (accep and !veto)
RpVeto::RpVeto(int flag, int nCmTra) : flag(flag)
{
  string base = "../out/rp/"+to_string(nCmTra)+"part/";

  if(flag == 1) // collect for veto
  {
    his_veto_effic.init(-1,1,400, -1,1,400, base+"veto_py.his");
    den_veto_effic.init(-1,1,400, -1,1,400, "");

    for(int topo = 0; topo < nTopos; topo++)
    {
      his_py12[topo].init(0.1,0.5,200,
                          0.1,0.5,200,
                          base+"py12_"+topos[topo]+".his");

      his_py12_pass[topo].init(0.1,0.5,200,
                               0.1,0.5,200,
                               base+"py12_"+topos[topo]+"_pass.his");

      his_py12_veto[topo].init(0.1,0.5,200,
                               0.1,0.5,200,
                               base+"py12_"+topos[topo]+"_veto.his");
    }
  }

  if(flag == 0) // read, calculate angular efficiency
  {
    cerr << Helper::col(2) << " reading roman pots !veto efficiency"
         << Helper::col();

    his_veto_effic.init(-1,1,400, -1,1,400, base+"veto_py.his");
    his_veto_effic.read();
 
    cerr << " [done]" << endl;
  }

  if(flag == 2) // read angular efficiency 
  {
    const double delKt = (maxKt-minKt)/3;

    cerr << Helper::col(2) << " reading roman pot angular efficiency"
         << Helper::col();
 
    for(int topo = 0; topo < nTopos; topo++)
    {
      cerr << ".";
      Histo & h = his_eff[topo];
      h.init(0,maxDphi,nDphi, minKt-delKt,maxKt+delKt,(5*nKt)/3,
                              minKt-delKt,maxKt+delKt,(5*nKt)/3,
             "../out/rp/eff_"+topos[topo]+".his");

      h.read();
    }
    cerr << " [done]" << endl;
  }
}

/*****************************************************************************/
RpVeto::~RpVeto()
{
  if(flag == 1) // normalize
    his_veto_effic.div(den_veto_effic);
}

/*****************************************************************************/
short int RpVeto::collectRegions(const vector<short int> & fixed)
{
  // collect regions
  map<short int,int> regs;
  for(short int pla = 0; pla < nPlanes; pla++)
  if(fixed[pla] != -99)
  {
    short int reg = fixed[pla] / wGroup;
    regs[reg]++;
  }

  // find region with highest occupancy
  short int mreg = -1;
  int rmax = -1;

  for(auto & r : regs)
  if(r.second > rmax)
  {
    mreg = r.first;
    rmax = r.second;
  }

  // region with max counts
  return mreg;
}

/*****************************************************************************/
// for re-applying on data
// for calculating efficiency tables
bool RpVeto::elasticVeto(const vector<RpTrack> & rpTracks, int sta,
                         bool print) // [4]
{
  short int regs[2][2]; // [topo][uv]

  for(auto & track : rpTracks)
  if(track.det.sta == sta) // far
  for(short int uv = 0; uv < 2; uv++)
  {
    vector<short int> strip(nPlanes);
    for(short int pla = 0; pla < nPlanes; pla++)
      strip[pla] = int(track.clus[uv][pla]); // FIXME rounding?

    // get regions
    const short int & arm = track.det.arm;
    regs[arm][uv] = collectRegions(strip);
  }

  // t-map
  bool veto = true;
  double y[2];

  const vector<int> c = {-1,1}; // PARAMETERS for {TB,BT}
//  const vector<int> c = {0,0}; // PARAMETERS for {TB,BT}
//  const vector<int> c = {1,-1}; // PARAMETERS for {TB,BT}
//  const vector<int> c = {-2,2}; // PARAMETERS for {TB,BT}
//  const vector<int> c = {0,0}; // PARAMETERS for {TB,BT}
  int topo = (rpTracks[0].det.rpt == 0 ? TB : BT);

  for(short int arm = 0; arm < 2; arm++)
  {
    veto &= (abs(regs[arm][0] - regs[arm][1] - c[topo]) <= 1 && // FIXME VERY
                 regs[arm][0] + regs[arm][1] >= 18);

    y[arm] = 25 - (regs[arm][0] + regs[arm][1]);


    if(print)
      cout << " " << regs[arm][0] - regs[arm][1] - c[topo]
           << " " << regs[arm][0] + regs[arm][1]
           << " " << y[arm];
  }

  veto &= (y[0] - y[1] == 0);

  if(print)
    cout << " " << (veto ? "veto" : "ok" );

  return veto;
}

/*****************************************************************************/
void RpVeto::combineTracks(const vector<RpTrack> & rpTracks, // [4]
                           const vector<PrTrack> & prTracks, // [2]
                           int topo, double rpWeight)
{
  bool print = false;

  if(topo == TT || topo == BB)
  {
    int mixSide;
    if(topo == TT) mixSide = 1; // bottom
              else mixSide = 0; // top

    rpStack[1-mixSide] = rpTracks; // put list to stack for opposite
    prStack[1-mixSide] = prTracks; // put list to stack for opposite

    const vector<RpTrack> & rpStacks = rpStack[mixSide]; // use list from stack
    const vector<PrTrack> & prStacks = prStack[mixSide]; // use list from stack

    if(print)
    cout << " a0" << endl;

    if(rpStacks.size() > 0)
    {
      vector<RpTrack> mxTracks = { rpStacks[0], rpStacks[1],   // arm 1 stack
                                   rpTracks[2], rpTracks[3] }; // arm 2 live

      if(print) cout << " a1 " << mxTracks.size() << endl;

      if(print)
      for(auto & t : mxTracks)
        cout << " ! " << t.det.print()
               << " " << t.pos.x
               << " " << t.pos.y << endl;

      if(print) cout << " a2" << endl;

      const double & p1y = prStacks[0].pt.y; // arm 1 stack
      const double & p2y = prTracks[1].pt.y; // arm 2 live

//      bool print = (fabs(p1y - 0.4) < 0.02 &&
//                    fabs(p2y + 0.4) < 0.02);

      if(print) cout << " " << topos[topo];

      mtx_veto.lock(); //

      if(!elasticVeto(mxTracks, 1, print))  // far only
        his_veto_effic.fill({p1y,p2y});

      den_veto_effic.fill({p1y,p2y});

      mtx_veto.unlock(); //

      if(print) cout << endl;

      if(print) getchar();
    }
  } 
}

/*****************************************************************************/
void RpVeto::checkVeto(const vector<RpTrack> & rpTracks, // [4],
                       const vector<PrTrack> & prTracks, // [2]
                       int topo, double rpWeight)
{
  mtx_check.lock(); //

  //
  his_py12[topo].fillw({fabs(prTracks[0].p.y),
                        fabs(prTracks[1].p.y)},rpWeight);

  if(elasticVeto(rpTracks, 1, false))
    his_py12_veto[topo].fillw({fabs(prTracks[0].p.y),
                               fabs(prTracks[1].p.y)},rpWeight);
  else
    his_py12_pass[topo].fillw({fabs(prTracks[0].p.y),
                               fabs(prTracks[1].p.y)},rpWeight);

  mtx_check.unlock(); //
}

/*****************************************************************************/
// same for both arms; for luminosity check
bool RpVeto::elasticMask(const vector<PrTrack> & prTracks, int topo)
{
  bool mask = false;

  if(topo == TB || topo == BT)
  {
    const double w = 0.070;
    const double d = 0.010;

    const double & p1y = prTracks[0].p.y;
    const double & p2y = prTracks[1].p.y;

    for(int i = 2; i <= 5; i++)
    {
      if(topo == TB)
      if(p1y >=  0.015-d + i*w && p1y <   0.015+d + (i+1)*w)
      if(p2y <  -0.025+d - i*w && p2y >= -0.025-d - (i+1)*w)
      { mask = true; break; }

      if(topo == BT)
      if(p1y <  -0.025+d - i*w && p1y >= -0.025-d - (i+1)*w)
      if(p2y >=  0.015-d + i*w && p2y <   0.015+d + (i+1)*w)
      { mask = true; break; }
    }
  }

  return mask;
}

/*****************************************************************************/
bool RpVeto::isAccepted(double py)
{
  return (fabs(py) > minPy &&
          fabs(py) < maxPy);
}

/*****************************************************************************/
int RpVeto::getTopology(double p1y, double p2y)
{
  if(p1y >= 0 && p2y <  0) return TB;
  if(p1y <  0 && p2y >= 0) return BT;
  if(p1y >= 0 && p2y >= 0) return TT;
  if(p1y <  0 && p2y <  0) return BB;

  exit(1);
}

/*****************************************************************************/
void RpVeto::calculateAngularEfficiency()
{
  cerr << Helper::col(1) << " simulating angular efficiency of roman pots"
                         << " [" << int(nEvents_rp_eff/1e+6) << " M events]"
       << Helper::col()  << endl << " ";

  Random theRandom;

  Histo his_all;
  vector<Histo> his_rec(nTopos);

  const double delKt = (maxKt-minKt)/3; // = 0.20 = (0.80 - 0.20)/3

  his_all.init(0,maxDphi,nDphi,
               minKt-delKt,maxKt+delKt,(5*nKt)/3,      // 0.00 - 1.00
               minKt-delKt,maxKt+delKt,(5*nKt)/3, ""); // 20 bins, 0.05 width

  for(int topo = 0; topo < nTopos; topo++)
  {
    Histo & h = his_rec[topo];
    h.init(0,maxDphi,nDphi, minKt-delKt,maxKt+delKt,(5*nKt)/3,
                            minKt-delKt,maxKt+delKt,(5*nKt)/3,
           "../out/rp/eff_"+topos[topo]+".his");
  }

  for(int i = 0; i < nEvents_rp_eff; i++)
  {
    if((i+1) % (nEvents_rp_eff/40) == 0) cerr << ".";

    double pt1 = theRandom.getFlat(minKt-delKt, maxKt+delKt);
    double pt2 = theRandom.getFlat(minKt-delKt, maxKt+delKt);

    double phi1 = theRandom.getFlat(0, 2*M_PI);
    double phi2 = theRandom.getFlat(0, 2*M_PI);

    // rotate
    double dphi = phi2 - phi1;
    if(dphi < -M_PI) dphi += 2*M_PI;
    if(dphi >  M_PI) dphi -= 2*M_PI;
    dphi = fabs(dphi);

    double py1 = pt1*sin(phi1);
    double py2 = pt2*sin(phi2);

    // acceptance
    double eff = (isAccepted(py1) &&
                  isAccepted(py2) ? 1 : 0);

    int topo = getTopology(py1,py2);

    // elastic veto efficiency
    if(topo == TB || topo == BT)
      eff *= his_veto_effic.val({py1,py2});

    // fill
    his_all.fill(       {dphi,pt1,pt2});
    his_rec[topo].fillw({dphi,pt1,pt2}, eff);
  }
  cerr << " [done]" << endl;

  // normalize
  for(int topo = 0; topo < nTopos; topo++)
    his_rec[topo].div(his_all);

  //
  Histo his_cov;

  his_cov.init(0,maxDphi,nDphi,
               minKt-delKt, maxKt+delKt, (5*nKt)/3,
               minKt-delKt, maxKt+delKt, (5*nKt)/3,
               "../out/rp/coverage.his");

  vector<int> ix(3);
  for(ix[0] = 0; ix[0] < his_cov.axes[0].bins; ix[0]++)
  for(ix[1] = 0; ix[1] < his_cov.axes[1].bins; ix[1]++)
  for(ix[2] = 0; ix[2] < his_cov.axes[2].bins; ix[2]++)
  {
          his_cov.get(ix) = pair<double,double>(0.0, 0);

    if(his_rec[0].get(ix).first > minRpEff ||
       his_rec[1].get(ix).first > minRpEff ||
       his_rec[2].get(ix).first > minRpEff ||
       his_rec[3].get(ix).first > minRpEff)
          his_cov.get(ix) = pair<double,double>(0.5, 0);

    if(his_rec[0].get(ix).first > minRpEff &&
       his_rec[1].get(ix).first > minRpEff &&
       his_rec[2].get(ix).first > minRpEff &&
       his_rec[3].get(ix).first > minRpEff)
          his_cov.get(ix) = pair<double,double>(1.0, 0);
  }
}

/*****************************************************************************/
double RpVeto::getAngularCoverage(int topo, const vector<float> & dphip1tp2t)
{
  return his_eff[topo].val(dphip1tp2t);
}


