#include "../interface/ProcessData.h"

#include <thread>
#include <algorithm>
#include <experimental/filesystem>

#include "../interface/RpPrint.h"
#include "../interface/RpPat.h"
#include "../interface/RpFit.h"
#include "../interface/RpEffic.h"
#include "../interface/RpReco.h"
#include "../interface/RpVeto.h"

#include "../interface/ParticleId.h"
#include "../interface/TrkEffic.h"
#include "../interface/TrkReco.h"
#include "../interface/Selection.h"

#include "../interface/Physics.h"

#include "../interface/Helper.h"
#include "../interface/gzstream.h"

#define sqr(x) ((x)*(x))

using namespace std;

/*****************************************************************************/
ProcessData::ProcessData(
  const string & data, int nCmTra, int nEvery, int nCpus,
                       const vector<string> & flags) :
  data(data), nCmTra(nCmTra), nEvery(nEvery), nCpus(nCpus), flags(flags)
{
  //
  cerr << Helper::col(6) << " [using " << data << "]" << Helper::col() << endl;

  //
  if(has("-rpPats" ))
  {
    theRpPat   = new RpPat(0, nCmTra);
    cerr << Helper::col(1)
         << " collecting roman pot strip patterns.."
         << Helper::col() << endl;
    return;
  }

  //
  if(has("-rpEffic"))
  {
    theRpEffic = new RpEffic(0, nCmTra);
    cerr << Helper::col(1)
         << " collecting roman pot strip efficiencies.."
         << Helper::col() << endl;
    return;
  }

  if(has("-rpVeto"))
  {
    theRpReco     = new RpReco(nCmTra, has("-readRpAlign"));
    theRpVeto     = new RpVeto(1, nCmTra); // collect
    return;
  }

  //
  if(has("-rpReco") || has("-doPhys"))
  {
    theRpReco     = new RpReco(nCmTra, has("-readRpAlign"));
    theRpVeto     = new RpVeto(2, nCmTra); // for elastic mask & ang cover

    if(nCmTra == 2)
    {
      theParticleId = new ParticleId(1);      // collect relsig
      theTrkEffic   = new TrkEffic(1);        // read simTables for getEffic
      theTrkReco    = new TrkReco(1);         // collect histos
    }

    theSelection  = new Selection(nCmTra, has("-readSelCuts"));

    cerr << Helper::col(1)
         << " reconstructing roman pot tracklets.."
         << Helper::col() << endl;
  }

  if(has("-doPhys"))
  {
    thePhysics = new Physics(nCmTra);

    cerr << Helper::col(1)
         << " doing physics.."
         << Helper::col() << endl;
  }
}

/*****************************************************************************/
ProcessData::~ProcessData()
{
  if(has("-rpPats" )) delete theRpPat;   // write strip patterns
  if(has("-rpEffic")) delete theRpEffic; // write strip effic
  if(has("-rpVeto" )) delete theRpVeto;  // write !veto (py1,py2) efficiency
  if(has("-rpReco" ) || has("-doPhys" )) // FIXME
  {
    delete theRpReco;  // write histos

    if(nCmTra == 2)
    {
      delete theParticleId;
      delete theTrkReco;
    }

    delete theSelection;

    //
    if(nCmTra == 2)
    {
      cerr << Helper::col(5) << " writing taken events.." << Helper::col();

      ofstream file("../out/lumi/takenEvents.dat");
      int orun = -1;

      for(auto & a : takenEvents)
      {
        const int & run = a.first.first;

        if(run != orun)
        {
          if(orun != -1) file << endl << endl;
          orun = run;
        }

        file << " " << a.first.first
             << " " << a.first.second
             << " ";
  
        for(int t = 0; t < nTopos; t++)
          file << " " << a.second[t];

        file << endl;
      }
      file.close();

      cerr << " [done]" << endl;
    }
  }

  if(has("-doPhys" )) delete thePhysics;
}

/*****************************************************************************/
bool ProcessData::has(const string & flag)
{
  return (find(flags.begin(), flags.end(), flag) != flags.end());
}

/*****************************************************************************/
bool ProcessData::readEvent(igzstream & fileIn, int nCmTra, Event & event)
{
  // clear
  event.run = -1;
  event.ls  = -1;
  event.bx  = -1;

  event.rpDets.clear();
  event.rpTracks.clear();
  event.prTracks.clear();
  event.cmTracks.clear();

  const bool rpPrint = has("-rpPrint");

  // read
  if(fileIn >> event.run >> event.ls >> event.bx)
  {
    int nDets;
    if(rpPrint)
      fileIn >> nDets;

    int nRpTracks;
    fileIn >> nRpTracks;

    if(rpPrint)
    {
      // roman pot dets
      for(int i = 0; i < nDets; i++)
      {
        RpDet det;
        int nClus;
        fileIn >> det.arm >> det.sta >> det.rpt >> det.pla >> nClus;

        det.sta /= 2; // 0 2 -> 0 1
        det.rpt %= 4; // 4 5 -> 0 1

        det.uv = det.pla % 2;
        det.pla /= 2;

        for(int j = 0; j < nClus; j++)
        {
          double strip;
          int width;

          fileIn >> strip >> width;
          if(strip == -1) strip = empty; // -1 -> -99
          det.clus.push_back(strip);
        }

        event.rpDets.push_back(det);
      }
    }

    // roman pot tracks
    for(int i = 0; i < nRpTracks; i++)
    {
      RpTrack track;
      RpDet   & det = track.det;
      Vector2 & pos = track.pos;

      fileIn >> det.arm >> det.sta >> det.rpt;

      bool ok = (det.sta == 0 || det.sta == 2) ||
                (det.rpt == 4 || det.rpt == 5);

      det.sta /= 2; // 0 2 -> 0 1
      det.rpt %= 4; // 4 5 -> 0 1

      float sigx, sigy;
      fileIn >> pos.x; if(!rpPrint) fileIn >> sigx;
      fileIn >> pos.y; if(!rpPrint) fileIn >> sigy;

      pos.cxx = sqr(sigx);
      pos.cyy = sqr(sigy);

      for(short int pla = 0; pla < nPlanes; pla++)
      for(short int uv = 0; uv < 2; uv++)
      {
        double strip;
        fileIn >> strip;

        if(det.print() == "0|0|0" && uv == 0 && pla == 2) // FIXME VERY
          strip = -1;

        if(strip == -1) strip = empty; // -1 -> -99
        track.clus[uv][pla] = strip;
      }

      //
      if(ok) event.rpTracks.push_back(track);
    }

    // cms track vertex
    if(!rpPrint)
    if(nCmTra > 0 && nCmTra != 9)
    {
      CmVertex & vtx = event.cmVertex;
      fileIn >> vtx.x.val
             >> vtx.y.val
             >> vtx.z.val;

      float cxx,cyy,czz;
      fileIn >> cxx >> cyy >> czz;
      vtx.x.sig = sqrt(cxx);
      vtx.y.sig = sqrt(cyy);
      vtx.z.sig = sqrt(czz);

      fileIn >> vtx.chi2 >> vtx.ndf;
    }

    // cms tracks
    if(nCmTra > 0 && nCmTra != 9)
    for(int i = 0; i < nCmTra; i++)
    {
      CmTrack track;
      string s;
      int nhits;

      fileIn
         >> track.eps >> s >> nhits
         >> track.q
         >> track.p.x >> track.p.y >> track.p.z;

      fileIn >> track.dt.val; if(!rpPrint) fileIn >> track.dt.sig;
      fileIn >> track.dz.val; if(!rpPrint) fileIn >> track.dz.sig;
      fileIn >> track.chi2 >> track.ndf;

      if(!rpPrint) fileIn >> track.sigpt;

      if(!fileIn.eof())
      {
        if(s != "inf" && s != "nan") track.sigma = stof(s);
                                else track.sigma = 1/0.;
        event.cmTracks.push_back(track);
      }
      else 
        return false;
    }

    // swap to +, -
    if(event.cmTracks.size() == 2)
    if(event.cmTracks[0].q < 0 && event.cmTracks[1].q > 0)
      swap(event.cmTracks[0], event.cmTracks[1]);

    return true;
  }
  else
    return false;
}

/*****************************************************************************/
bool ProcessData::processEvent(Event & event)
{
  if(has("-rpPrint"))
  { 
    RpPrint theRpPrint;
    theRpPrint.print(event.rpDets, event.rpTracks);

    getchar();

    return true;
  }

  // need exactly four tracklets, proper topology
  if(theRpReco->getTopo(event.rpTracks, event.topo))
  {
    // collect patterns
    if(has("-rpPats"))
    {
      theRpPat->collectPatterns(event.rpTracks);
      return true;
    }

    // collect efficiency
    if(has("-rpEffic"))
    {
      theRpEffic->collectStrip(event.rpTracks, event.run);
      return true;
    }

    // extract roman pots !veto efficiency using TT,BB tracks
    if(has("-rpVeto"))
    if(theRpReco->reconstruct(event))
    {
      theRpVeto->combineTracks(event.rpTracks, event.prTracks,
                               event.topo, event.rpWeight);

      theRpVeto->checkVeto(event.rpTracks, event.prTracks,
                           event.topo, event.rpWeight);
      return true;
    }

    // reconstruct rp or physics
    if(has("-rpReco") || has("-doPhys"))
    {
      // guess trkWeight
      if(nCmTra == 2)
      {
        double trkEff =
          theTrkEffic->getEfficiency(event.cmTracks, pion); // guess
        if(trkEff < 1e-2) trkEff = 1e-2; // FIXME

        // calculate track weight
        event.trkWeight = 1/trkEff;
      }
      else
        event.trkWeight = 1;

      // roman pots reconstruction | problems with global vars in RpFit (my_*)
      // get event.rpWeight
      bool isWithin = theRpReco->reconstruct(event);

/*
      theRpVeto->checkVeto(event.rpTracks, event.prTracks,
                           event.topo, event.rpWeight);
*/

      //////////////////////////////////////////////////////////////
      // event filters
      bool isAlright = true;
      event.type = unknown;

/**************************************** LOCK *******************************/
      mtx_his.lock(); // lock

      // fill hit locations
      if(nCmTra == 2)
      {
        double sumpx = event.prTracks[0].p.x + event.prTracks[1].p.x
                     + event.cmTracks[0].p.x + event.cmTracks[1].p.x;

        double sumpy = event.prTracks[0].p.y + event.prTracks[1].p.y
                     + event.cmTracks[0].p.y + event.cmTracks[1].p.y;

        double z = (sqr(sumpx/0.150) + sqr(sumpy/0.060)); // guessed

        if(z < 1)
          theRpReco->fill_hits_loc(event.topo, event.run,
                                   event.rpTracks,
                                   event.rpWeight*event.trkWeight);
      }
      else
          theRpReco->fill_hits_loc(event.topo, event.run,
                                   event.rpTracks,
                                   event.rpWeight*event.trkWeight);
      mtx_his.unlock(); // lock

      // stay only if minPy < |py| < maxPy
      if(!isWithin)
        return false;

      mtx_his.lock(); // lock

      //
      if(nCmTra == 2)
      {
        theTrkReco->collectPars(event.cmTracks); // collect

        // identify pair
        event.type = theParticleId->identifyPair(event.cmTracks);
        if(event.type == unknown)
          isAlright = false;

        // guess pid, looper removal (|sum p| / mass < 0.2)
        int typeGuess = (event.type != unknown ? event.type : pion);
        if(theSelection->areCmTracksLooper(event,typeGuess, event.rpWeight))
          isAlright = false;

        // primary central hadrons (|vertex r| < 1 cm, |z - z0| < 4 sig)
        if(!theSelection->areCmTracksPrimaries(event, event.rpWeight))
          isAlright = false;
      }

      // primary scattered protons (|dx| < 80 um)
      if(!theSelection->areRpProtonsPrimaries(event, event.rpWeight))
        isAlright = false;

      //////////////////////////////////////////////////////////////
      // filtered events only
      // central hadrons are (not looper, compat with IP, identified, same type)
      // scattrd protons are (compat with each other at IP)
      if(isAlright)
      {
        // classify event
        vector<float> dphip1tp2t;
        {
          const Vector3 & p1 = event.prTracks[0].p;
          const Vector3 & p2 = event.prTracks[1].p;

          const double dphi = fabs(p1.dphi(p2));

          dphip1tp2t = {dphi, p1.trans(), p2.trans()};
        }

        event.cat = theSelection->classifyEvent(event, event.topo,
                                                event.rpWeight);

        theSelection->fillRpX12(event, event.rpWeight); // fill his_rp_x12

        // determine event sign
        event.sign = 0;
        if(event.cat == signal)   event.sign =  1;
        if(event.cat == sideband) event.sign = -1;

        if(nCmTra == 2)
        {
          // collect
          theParticleId->processEnergyLoss(event.cmTracks,
                                           event.cat, event.type);

          // signal or sideband
          if(event.sign != 0)
          {
            theTrkReco->collectChi2(event.cmTracks, event.type); // collect

            // for takenEvents
            // - track |eta| < 2.5 and pT > 0.10 GeV
            // - larger mask of (p1y,p2y)
            if(theTrkReco->hasGoodEffic(event.cmTracks))
            if(!theRpVeto->elasticMask(event.prTracks, event.topo))
            { // collect for luminosity comparison
              pair<int,int> loc(event.run,event.ls);

              // get pair efficiency with PID
              double trkEff =
                theTrkEffic->getEfficiency(event.cmTracks, event.type);
              if(trkEff < 1e-2) trkEff = 1e-2; // FIXME

              // calculate track weight
              event.trkWeight = 1/trkEff;

              // sum
              takenEvents[loc][event.topo] +=
                 event.sign * event.rpWeight * event.trkWeight;
            }

            // do physics [sign, effIntLumi, rpWeight, rpCover, cmEffic]
            if(has("-doPhys"))
              thePhysics->process(event);
          }
        }
      }

      mtx_his.unlock(); // unlock
/**************************************** UNLOCK *****************************/

      return true;
    }
  }

  return false; 
}

/*****************************************************************************/
void ProcessData::readStreams(const vector<string> & dataStreams)
{
  // take all streams
  for(auto & dataStream : dataStreams)
  {
    const string path = "../data/"+data+"/"+dataStream+"/";

    if(experimental::filesystem::exists(path))
    {
      int nFiles = 0;

      mtx_cerr.lock();
      cerr << " " << dataStream;
      mtx_cerr.unlock();

      // all files
      for(const auto & entry :
          experimental::filesystem::directory_iterator(path))
      if(nFiles++ % nEvery == 0)
      {
        igzstream fileIn(entry.path().string().c_str());

        //
        Event event;

        while(readEvent(fileIn, nCmTra, event))
        {
          if(processEvent(event))
          {
            mtx_count.lock();
            nEvents++; Helper::propeller(nEvents, 100000);
            mtx_count.unlock();
          }
        }

        fileIn.close();
      }
    }
  }
}

/*****************************************************************************/
void ProcessData::readData()
{
  nEvents = 0;

  // setup lists
  vector<vector<string>> lists =
    Helper::getStreams(nCpus, false); // has("-rpVeto")); // for rp_veto -> paraOnly

  cerr << " reading";

  // initialize threads
  vector<thread> threads;
  for(auto & list : lists)
    threads.push_back(thread(&ProcessData::readStreams,this,list));

  // start and wait
  for(auto & thread : threads)
    thread.join();

  cerr << endl;

  // final report
  if(nEvents > 1e+6)
    cerr << " [read " << int(nEvents/1e+6 * 100)/100. << " M events]";
  else
    cerr << " [read " <<     nEvents                  <<   " events]";

  cerr << endl;
}

