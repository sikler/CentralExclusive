#include <iostream>

#include "../interface/Parameters.h"
#include "../interface/Histo.h"

using namespace std;

//
void multiply(int topo, /*const*/ Histo a[], /*const*/ Histo & b, Histo & c)
{
  for(int ix = 0; ix < a[topo].axes[0].bins; ix++)
  for(int iy = 0; iy < a[topo].axes[1].bins; iy++)
  {
    vector<float> xa = { a[topo].axes[0].center(ix),
                         a[topo].axes[1].center(iy) };

    vector<float> xb = xa;

    if(topo == TB) { xb[1] = - xb[1]; }
    if(topo == BT) { xb[0] = - xb[0]; }

    if(b.val(xb) != 0)
      c.set(xa, a[topo].val(xa) / b.val(xb));
    else
      c.set(xa, 0);
  }
}

//
int main()
{
  //
  Histo his_py12[nTopos];

  for(int topo = 0; topo < 2; topo++)
  {
    his_py12[topo].init(0.1,0.5,200, 0.1,0.5,200,
                        "../out/rp/2part/py12_"+topos[topo]+".his");
    his_py12[topo].read();
  }

  //
  Histo his_veto_effic;
  his_veto_effic.init(-1,1,400, -1,1,400,
                      "../out/rp/2part/veto_py.his");
  his_veto_effic.read();

  //
  for(int topo = 0; topo < 2; topo++)
  {
    Histo his_out;
    his_out.init(0.1,0.5,200, 0.1,0.5,200,
                 "../out/rp/2part/py12_check_"+topos[topo]+".his");

    multiply(topo, his_py12, his_veto_effic, his_out);

    his_out.write();
  }
}
